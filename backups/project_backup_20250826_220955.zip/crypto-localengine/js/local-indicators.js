export function sma(values, period){
  const out = new Array(values.length).fill(null);
  let sum=0; for(let i=0;i<values.length;i++){ sum+=values[i]; if(i>=period) sum-=values[i-period]; if(i>=period-1) out[i]=sum/period; }
  return out;
}
export function ema(values, period){
  const out=new Array(values.length).fill(null), k=2/(period+1);
  let prev=0, started=false;
  for(let i=0;i<values.length;i++){
    const v=values[i];
    if(!started){ prev=v; if(i>=period-1){ started=true; out[i]=prev; } }
    else{ prev=v*k+prev*(1-k); out[i]=prev; }
  } return out;
}
export function rsi(c, p=14){
  const out=new Array(c.length).fill(null);
  let g=0,l=0; for(let i=1;i<=p;i++){ const d=c[i]-c[i-1]; g+=Math.max(0,d); l+=Math.max(0,-d); }
  let G=g/p, L=l/p; out[p]=100-(100/(1+(G/(L||1e-9))));
  for(let i=p+1;i<c.length;i++){ const d=c[i]-c[i-1]; G=(G*(p-1)+Math.max(0,d))/p; L=(L*(p-1)+Math.max(0,-d))/p; const rs=G/(L||1e-9); out[i]=100-(100/(1+rs)); }
  return out;
}
export function macd(c, fa=12, sl=26, sg=9){
  const ef=ema(c,fa), es=ema(c,sl);
  const m=c.map((_,i)=> (ef[i]!=null&&es[i]!=null)?ef[i]-es[i]:null);
  const s=ema(m.map(x=>x??0), sg);
  const h=m.map((v,i)=> (v!=null&&s[i]!=null)?v-s[i]:null);
  return { macd:m, signal:s, hist:h };
}
export function atr(h,l,c,p=14){
  const tr=[null]; for(let i=1;i<c.length;i++){ const a=h[i]-l[i], b=Math.abs(h[i]-c[i-1]), d=Math.abs(l[i]-c[i-1]); tr.push(Math.max(a,b,d)); }
  const out=new Array(c.length).fill(null); let A=0; for(let i=1;i<=p;i++) A+=tr[i]; A/=p; out[p]=A;
  for(let i=p+1;i<tr.length;i++){ A=(A*(p-1)+tr[i])/p; out[i]=A; } return out;
}
export function bb(c, p=20, mult=2){
  const mid=sma(c,p), up=new Array(c.length).fill(null), lo=new Array(c.length).fill(null);
  for(let i=p-1;i<c.length;i++){ const s=c.slice(i-p+1,i+1); const mean=mid[i]; const v=s.reduce((a,v)=>a+(v-mean)**2,0)/p; const sd=Math.sqrt(v); up[i]=mean+mult*sd; lo[i]=mean-mult*sd; }
  return { mid, upper:up, lower:lo };
}
export function obv(c, v){
  const out=[0]; for(let i=1;i<c.length;i++){ out[i]=out[i-1]+(c[i]>c[i-1]?v[i]:(c[i]<c[i-1]?-v[i]:0)); } return out;
}
