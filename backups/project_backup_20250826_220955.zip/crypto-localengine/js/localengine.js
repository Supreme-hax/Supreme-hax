import { ema, rsi, macd, atr, bb, obv } from './local-indicators.js';

const TF_ORDER = ["15m","1h","4h","1d"];
const TF_TO_BINANCE = { "15m":"15m", "1h":"1h", "4h":"4h", "1d":"1d" };

async function fetchKlines(symbol, tf, kind="spot", limit=500){
  const interval = TF_TO_BINANCE[tf];
  const base = (kind==="perp") ? "https://fapi.binance.com" : "https://api.binance.com";
  const path = (kind==="perp") ? "fapi/v1" : "api/v3";
  const url = `${base}/${path}/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  const res = await fetch(url);
  if(!res.ok) throw new Error(`${kind} klines ${res.status}`);
  const raw = await res.json();
  return raw.map(k => ({ t:k[0], o:+k[1], h:+k[2], l:+k[3], c:+k[4], v:+k[5] }));
}

function sectionId(kind, tf){ return `le_${kind}_${tf}`; }
function toStamp(ms){ return new Date(ms).toISOString().slice(0,16).replace(/[:T]/g,''); }

function addSection(container, title, subtitle, id){
  const wrap = document.createElement('div');
  wrap.className='le-section';
  wrap.innerHTML = `
    <div class="le-toolbar">
      <div><span class="le-title">${title}</span><span class="le-subtle"> • ${subtitle}</span></div>
      <div><button class="le-btn" data-dl="${id}">Download</button></div>
    </div>
    <div id="${id}" class="le-chart"></div>
  `;
  container.appendChild(wrap);
  return wrap;
}

async function render(el, kl){
  const t = kl.map(k=>new Date(k.t)), o=kl.map(k=>k.o), h=kl.map(k=>k.h), l=kl.map(k=>k.l), c=kl.map(k=>k.c), v=kl.map(k=>k.v);

  const e20=ema(c,20), e50=ema(c,50), e200=ema(c,200);
  const bb20=bb(c,20,2);
  const rsi14=rsi(c,14);
  const m=macd(c,12,26,9);
  const A=atr(h,l,c,14);
  const obvL=obv(c,v);

  const data = [
    { x:t, open:o, high:h, low:l, close:c, type:'candlestick', xaxis:'x', yaxis:'y', name:'Price' },
    { x:t, y:e20, type:'scatter', mode:'lines', line:{width:1.4,color:'#54a900'}, name:'EMA20', xaxis:'x', yaxis:'y' },
    { x:t, y:e50, type:'scatter', mode:'lines', line:{width:1.2,color:'#2e7dd7'}, name:'EMA50', xaxis:'x', yaxis:'y' },
    { x:t, y:e200, type:'scatter', mode:'lines', line:{width:1.2,color:'#b36ae2'}, name:'EMA200', xaxis:'x', yaxis:'y' },
    { x:t, y:bb20.upper, type:'scatter', mode:'lines', line:{width:1,color:'#888'}, name:'BB U', xaxis:'x', yaxis:'y' },
    { x:t, y:bb20.mid,   type:'scatter', mode:'lines', line:{width:1,color:'#666'}, name:'BB M', xaxis:'x', yaxis:'y' },
    { x:t, y:bb20.lower, type:'scatter', mode:'lines', line:{width:1,color:'#888'}, name:'BB L', xaxis:'x', yaxis:'y' },

    { x:t, y:v, type:'bar', marker:{color:'#585b66'}, name:'Volume', xaxis:'x', yaxis:'y1b' },

    { x:t, y:rsi14, type:'scatter', mode:'lines', line:{width:1.4,color:'#e2b714'}, name:'RSI', xaxis:'x2', yaxis:'y2' },

    { x:t, y:m.macd, type:'scatter', mode:'lines', line:{width:1.4,color:'#2db67c'}, name:'MACD', xaxis:'x3', yaxis:'y3' },
    { x:t, y:m.signal, type:'scatter', mode:'lines', line:{width:1.4,color:'#d94d4d'}, name:'Signal', xaxis:'x3', yaxis:'y3' },
    { x:t, y:m.hist, type:'bar', marker:{color:'#888'}, name:'Hist', xaxis:'x3', yaxis:'y3' },

    { x:t, y:A, type:'scatter', mode:'lines', line:{width:1.4,color:'#b38e5d'}, name:'ATR', xaxis:'x4', yaxis:'y4' },

    { x:t, y:obvL, type:'scatter', mode:'lines', line:{width:1.2,color:'#9aa0a6'}, name:'OBV', xaxis:'x5', yaxis:'y5' }
  ];

  const layout = {
    paper_bgcolor:'#161823', plot_bgcolor:'#161823', font:{color:'#e6e6e6'}, showlegend:false,
    margin:{l:55,r:15,t:6,b:6},
    grid:{rows:5, columns:1, pattern:'independent', roworder:'top to bottom'},
    xaxis:{domain:[0,1]},     yaxis:{domain:[0.62,1.00]},
    xaxis1b:{overlaying:'x', visible:false}, yaxis1b:{domain:[0.62,1.00], overlaying:'y', anchor:'x'},
    xaxis2:{domain:[0,1]},    yaxis2:{domain:[0.46,0.60]},
    xaxis3:{domain:[0,1]},    yaxis3:{domain:[0.30,0.44]},
    xaxis4:{domain:[0,1]},    yaxis4:{domain:[0.16,0.28]},
    xaxis5:{domain:[0,1]},    yaxis5:{domain:[0.04,0.14]},
    shapes:[ { type:'line', xref:'paper', x0:0, x1:1, yref:'y2', y0:50, y1:50, line:{color:'#444',width:1,dash:'dot'} } ]
  };
  const config = { responsive:true, displayModeBar:false };
  await Plotly.newPlot(el, data, layout, config);
}

async function buildOne(kind, symbol, tf){
  const root = document.getElementById('localengine_root');
  const id = sectionId(kind, tf);
  const head = `${symbol} • ${kind.toUpperCase()} • ${tf.toUpperCase()}`;
  const wrap = addSection(root, head, 'Local indicators + Download', id);

  const kl = await fetchKlines(symbol, tf, kind==='perp'?'perp':'spot', 500);
  const node = document.getElementById(id);
  await render(node, kl);

  wrap.querySelector(`[data-dl="${id}"]`).onclick = async () => {
    const url = await Plotly.toImage(node, {format:'png', scale:2, width: node.clientWidth, height: node.clientHeight});
    const stamp = toStamp(kl[kl.length-1].t);
    const a = document.createElement('a'); a.href=url; a.download=`${symbol}_${kind}_${tf}_${stamp}.png`; a.click();
  };
}

export const LocalEngine = {
  async build(){
    const symbol = (document.getElementById('le_symbol').value||'ETHUSDT').toUpperCase().trim();
    const incSpot = document.getElementById('le_inc_spot').checked;
    const incPerp = document.getElementById('le_inc_perp').checked;

    const root = document.getElementById('localengine_root');
    root.innerHTML = ''; // reset

    const jobs = [];
    if(incSpot){ for(const tf of TF_ORDER) jobs.push(()=>buildOne('spot', symbol, tf)); }
    if(incPerp){ for(const tf of TF_ORDER) jobs.push(()=>buildOne('perp', symbol, tf)); }

    // Sequential to reduce memory spikes
    for(const job of jobs){ try{ await job(); } catch(e){ console.warn('Section fail:', e.message); } }

    document.getElementById('modalAutoSetup').style.display='none';
    root.scrollTo({top:0, behavior:'smooth'});
  }
};
window.LocalEngine = LocalEngine;
