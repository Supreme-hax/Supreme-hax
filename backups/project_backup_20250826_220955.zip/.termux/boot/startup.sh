#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock
pm2 resurrect
